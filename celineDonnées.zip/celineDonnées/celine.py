import pandas as pd
from datetime import datetime
import re
import numpy as np

# Get the data
genres = ('Unknown', 'Action', 'Adventure', 'Animation',
          'Children', 'Comedy', 'Crime', 'Documentary',
          'Drama', 'Fantasy', 'Film-Noir', 'Horror',
          'Musical', 'Mystery', 'Romance', 'Sci-Fi',
          'Thriller', 'War', 'Western')

ratings = pd.read_table('ml-100k/u.data',
                        delimiter = r'\s+',
                        names = ('userID', 'filmID', 'score', 'timeStamp'))
films = pd.read_table('ml-100k/u.item',
                      delimiter = '|',
                      encoding = 'latin-1',
                      index_col = False,
                      names = ('filmID', 'title', 'releaseDate',
                               'videoReleaseDate', 'IMDbURL',
                               'Unknown', 'Action', 'Adventure', 'Animation',
                               'Children', 'Comedy', 'Crime', 'Documentary',
                               'Drama', 'Fantasy', 'Film-Noir', 'Horror',
                               'Musical', 'Mystery', 'Romance', 'Sci-Fi',
                               'Thriller', 'War', 'Western'))
users = pd.read_table('ml-100k/u.user',
                      delimiter = '|',
                      names = ('userID', 'age', 'gender', 'occupation', 'zip'))
                      
# Convert the UNIX timestamps to datetimes
ratings['timeStamp'] = ratings['timeStamp'].apply(datetime.fromtimestamp)
# Get the genre of each movie
filmGenres = {}
filmsRows = films.iterrows()
for i, film in filmsRows:
    filmGenres[film['filmID']] = [genre for genre in genres if film[genre]]

# Join the dataframes
tmp = pd.merge(ratings, films)
df = pd.merge(tmp, users)
                      
# Add the concatenated genres of a movie to the dataframe
df['genre'] = None
for i in range(df.shape[0]):
    genre = '/'.join(filmGenres[df.ix[i]['filmID']])
    df['genre'][i] = genre

df = df[['userID', 'filmID', 'score', 'timeStamp',
         'title', 'releaseDate', 'age', 'gender',
         'occupation', 'zip', 'genre']]

# Split genres
genres = ('Action', 'Adventure', 'Animation',
          'Children', 'Comedy', 'Crime', 'Documentary',
          'Drama', 'Fantasy', 'Film-Noir', 'Horror',
          'Musical', 'Mystery', 'Romance', 'Sci-Fi',
          'Thriller', 'War', 'Western')

# Concatenate
df['concatenated'] = df['filmID'] + df['title'] + \
                    ',' + str(df['score'])+ ',' + \
                    ',' + df['releaseDate'] + ',' + str(df['age']) 

# Split genres
df = pd.concat([pd.Series([row['concatenated']], row['genre'].split('/'))              
                   for _, row in df.iterrows()]).reset_index()
df.columns = ('genre', 'concatenated')
df['concatenated'] = df['concatenated'] + ',' + df['genre']
# Split column
df = pd.DataFrame(df.concatenated.str.split(',').tolist(),
                                   columns = ['gender', 'occupation',
                                              'region', 'ageCategory',
                                              'releaseDecade', 'genre'])
# Save
df.to_csv('data/celine', index = False)
