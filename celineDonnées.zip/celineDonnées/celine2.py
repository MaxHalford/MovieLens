from pymongo import MongoClient
import pandas as pd

'''
Release Decades
'''
# Open the CSV file with the categorized data
df = pd.read_csv('data/celine')

# Concatenate
df['concatenated'] = df['score'].apply(str) + ';' + df['filmID'].apply(str) + \
                     ';' + df['timeStamp'].apply(str) + ';' + df['releaseDate'] + \
                     ';' + df['title'].apply(str) + \
                     ';' + df['gender'].apply(str) + ';' + df['zip'].apply(str) + \
                     ';' + df['occupation'].apply(str)
# Split genres
df2 = pd.concat([pd.Series([row['concatenated']], row['genre'].split('/'))              
                   for _, row in df.iterrows()]).reset_index()
df2.columns = ('genre', 'concatenated')
df2['concatenated'] = df2['concatenated'] + ';' + df2['genre']

rows = df2.concatenated.str.split(';').tolist()

rows = [pd.Series(row) for row in rows]
nDf = pd.DataFrame(rows)
nDf.columns = ['score', 'filmID', 'timeStamp', 'releaseDate',
           'title', 'gender', 'zip', 'occupation', 'genre']

# Save
#df.to_csv('data/celine', index = False)
